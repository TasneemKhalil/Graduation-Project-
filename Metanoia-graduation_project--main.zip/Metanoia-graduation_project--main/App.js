import StartingPage from './screens/StartingPage';
// import * as friebase from 'firebase';
import App2 from './Notification';

// import { LogBox } from 'react-native';
export default function App() {
  return (
    <StartingPage />
    // <App2/>
    // LogBox.ignoreLogs(['Invalid prop textStyle of type array supplied to Cell']);
  );
}

// friebase.initializeApp(firebaseConfig)
