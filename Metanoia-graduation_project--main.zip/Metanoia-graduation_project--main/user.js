
var userr = "asma";
var pass = 123;
var id = 0;
const userPage = (username, password) => {
  // userr= "asma";
  // pass= 123;
  // id = 0

  // userr = username;
  // pass = password;
 
}

export default userPage
export {userr, pass, id}