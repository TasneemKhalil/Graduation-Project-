# Metanoia-graduation_project-
app about task management and a little community within.
