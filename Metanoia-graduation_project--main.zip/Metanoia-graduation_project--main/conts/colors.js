const COLORS = {
    white: '#fff',
    black: '#000',
    blue: '#5D5FEE',
    grey: '#656565',//'#BABBC3',
    light: '#F3F4FB',
    darkBlue: '#7978B5',
    red: 'red',
    ////////////////
    A_dark_blue:'#0078AA',
    A_blue: '#3AB4F2',//'#3AB4F2',
    A_gray: '#222222',//'#808080',
    A_yellow: '#F2DF3A',
    A_white: '#F6F6F6'
  };
  export default COLORS;
  